package J05046;

import java.util.ArrayList;
import java.util.Scanner;

public class J05046 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<MatHang> a = new ArrayList<>();
        ArrayList<String> b = new ArrayList<>();
        int n = Integer.parseInt(sc.nextLine());
        for (int i = 0; i < n; i++) {
            a.add(new MatHang(sc.nextLine(), Integer.parseInt(sc.nextLine()), Integer.parseInt(sc.nextLine())));
            int index = b.indexOf(a.get(i).getId().substring(0, 2));
            if (index == -1) {
                a.get(i).setId(1);
            } else {
                a.get(i).setId(Integer.parseInt(a.get(b.lastIndexOf(a.get(i).getNameId())).getId().substring(2)) + 1);
            }
            b.add(a.get(i).getNameId());
        }
        a.forEach(System.out::println);
    }
}
// 3
// May lanh SANYO
// 12
// 4000000
// Dien thoai Samsung
// 30
// 3230000
// Dien thoai Nokia
// 18
// 1240000